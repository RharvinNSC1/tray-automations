# Changelog
All notable changes to the **RPM Adherence** automation.

## [2.3.0] - 2025-09-16

- Added: Create Gmail configuration data.
- Changed: Send message (Gmail node) properties set.
- Added: Create **Terminate – Fail Run** node (temporary for testing).
- Test: RPM Adherence Alert workflow testing.
- Removed: **Terminate – Fail Run** node.

**Artifact:** `project_RPM Adherence_v2.3.json`  
