# Changelog
All notable changes to the **Bland Post Call Webhook** automation (Tray JSON export) are documented here.
This project follows [Semantic Versioning](https://semver.org/).

## [3.0.0] - 2025-09-17
### Added
- Bland webhook alert workflow testing to validate end-to-end alert delivery and regression behavior.
- Workflow capability to utilize Bland citations when present (e.g., pass through to logs/metadata and downstream steps).

### Changed
- Configuration adjusted to support both **live** and **mock** data testing paths (switchable via Tray config), allowing safe validation without hitting production resources.

---

**Artifact:** `Bland-Post-Call-Webhook.v3.json`

<!-- Optional: add a compare link once you tag releases
[3.0.0]: https://github.com/<org>/<repo>/compare/v2.?.?....v3.0.0
-->
