# Angyla-AI-Automations
Repository for storing Tray.io project version JSON exports for Nsight Health automations.

This repository stores **Tray.io workflow and project version exports (JSON files)** used at Nsight Health.  
It is intended as a central version-control system for automations, supporting collaboration, auditing, and deployment across environments.

---

- `<automation-name>` → The Tray project name (e.g., `voice-ai`, `rpm-rapport`, `angyla-test-portal`)  
- `<environment>` → One of: `dev`, `qa`, `stage`, `prod`  
- `<major.minor>` → Tray versioning format (e.g., `1.0`, `1.1`, `2.0`)  

Examples:
- `voice-ai-dev-v1.0.json`  
- `rpm-rapport-prod-v2.1.json`  
- `angyla-test-portal-qa-v1.3.json`  

---

Environments

Standard environment labels:  
- `dev` → Development  
- `qa` → Quality Assurance  
- `stage` → Staging  
- `prod` → Production  

---

Export & Import Process

Export from Tray
1. Open the **project** in Tray.io.  
2. Select **Export JSON**.  
3. Save the file locally using the naming convention above.  
4. Commit and push to this repository under the correct folder.  

Import into Tray
1. Download the JSON file from this repo.
2. Log into the Tray.io app.
3. Navigate to the correct workspace (e.g., Angyla AI – <environment>).
4. Open the respective Project inside that workspace.
5. In the left navigation pane, scroll to the bottom and click Project versions.
6. On the Project versions page, click the Import project version button in the top-right corner.
7. Upload the JSON file you downloaded.
8. Verify that the environment and version match before deployment.

---

Semantic Versioning

**major.minor.patch**

